## Klasemen Sepak Bola App
Membuat aplikasi klasemen sepak bola, terdapat fitur:
- Input data club
- Input data pertandingan
- hasil klasemen
Teknologi yang digunakan menggunakan Javascript berbasis komponen modul. Serta terdapat fitur PWA untuk menginstall Aplikasi.

## Demo
Silahkan kunjungi **[https://klasemen-bola-app.netlify.app](https://klasemen-bola-app.netlify.app)** untuk melihat hasil jadi Aplikasi.